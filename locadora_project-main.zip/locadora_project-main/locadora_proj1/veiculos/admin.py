from django.contrib import admin
from .models import Automovel

# Register your models here.
admin.site.register(Automovel)